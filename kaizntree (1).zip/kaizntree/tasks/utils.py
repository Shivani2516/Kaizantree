from django.db import transaction
from .models import Item, ItemCategory, Tag


def add_item(data):
    with transaction.atomic():
        category_data = data['category']
        category, _ = ItemCategory.objects.get_or_create(name=category_data['name'], defaults=category_data)

        tags = []
        for tag_data in data['tags']:
            tag, _ = Tag.objects.get_or_create(name=tag_data['name'], defaults=tag_data)
            tags.append(tag)

        # Create the item
        item = Item.objects.create(
            sku=data['sku'],
            name=data['name'],
            category=category,
            in_stock=data['in_stock'],
            available_stock=data['available_stock']
        )

        item.tags.set(tags)

        return item


data = {
    "sku": "SKU2",
    "name": "Car Trash Can",
    "category": {
        "name": "Trash Can"
    },
    "tags": [
        {"name": "Trash Can"},
        {"name": "New"}
    ],
    "in_stock": "100.000",
    "available_stock": "80.000"
}

if __name__=="__main":
    item = add_item(data)
    print(f"Item '{item.name}' added successfully with ID: {item.id}")