from rest_framework import serializers
from .models import Item, ItemCategory, Tag


class ItemCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemCategory
        fields = ['id', 'name']


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'name']


class ItemSerializer(serializers.ModelSerializer):
    category = ItemCategorySerializer(read_only=True)
    tags = TagSerializer(many=True, read_only=True)

    class Meta:
        model = Item
        fields = ['sku', 'name', 'category', 'tags', 'in_stock', 'available_stock']
