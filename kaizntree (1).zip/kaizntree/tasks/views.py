from django.db.models import Q
from rest_framework import generics
from .models import Item
from .serializers import ItemSerializer
from rest_framework.permissions import IsAuthenticated


class ItemList(generics.ListAPIView):
    serializer_class = ItemSerializer

    def get_queryset(self):
        queryset = Item.objects.all()
        query_params = self.request.query_params
        serializer_class = ItemSerializer
        permission_classes = [IsAuthenticated]

        # Filter by SKU
        sku = query_params.get('sku', None)
        if sku:
            queryset = queryset.filter(sku=sku)

        # Filter by Name
        name = query_params.get('name', None)
        if name:
            queryset = queryset.filter(name__icontains=name)

        # Filter by Category ID
        category_id = query_params.get('category_id', None)
        if category_id:
            queryset = queryset.filter(category__id=category_id)

        # Filter by Tag IDs
        tag_ids = query_params.getlist('tag_ids', None)  # 'tag_ids' should be passed as a list of IDs
        if tag_ids:
            # The filter below assumes you want items that have all the tags specified
            for tag_id in tag_ids:
                queryset = queryset.filter(tags__id=tag_id)

        # You can add more filtering logic based on other fields if necessary

        return queryset.distinct()  # Ensure we return distinct items if they match multiple tags
